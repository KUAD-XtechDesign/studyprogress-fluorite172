function setup() {
  createCanvas(600, 600);

translate (width/2, height/2);
for (let i = 0; i < 16; i++) {
  fill (0)
    
  rect (-270, -3, 540, 6)
    rotate(PI / 8)
  ;}}
function draw() {
  //background(220);
}